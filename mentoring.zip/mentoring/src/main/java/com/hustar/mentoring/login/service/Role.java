package com.hustar.mentoring.login.service;



public enum Role {
	ROLE_MEMBER, 
	ROLE_MENTO
	;
}
