package com.hustar.mentoring.login.service;

import com.hustar.mentoring.login.domain.MemberDomain;

public interface Judgement {
	void insertMemberInfo(MemberDomain memberDomain);
}
