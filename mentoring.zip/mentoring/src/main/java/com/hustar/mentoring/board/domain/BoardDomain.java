package com.hustar.mentoring.board.domain;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardDomain extends SearchDomain{
	
	private String boardSeq;
	private String boardTitle;
	private String boardContents;
	private String boardCreateDate;
	private String boardModifyDate;
	private String boardFilePath1;
	private String boardFilePath2;
	private String boardFilePath3;
	
	
	private MultipartFile boardFile1;
	private MultipartFile boardFile2;
	private MultipartFile boardFile3;
	
}
