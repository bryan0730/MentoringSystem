package com.hustar.mentoring.board.config;

import java.io.File;
import java.util.UUID;

import org.springframework.util.FileCopyUtils;

public class UploadFileUtils {
	
	// 파일 업로드
		public static String fileUpload(String uploadPath, String fileName, byte[] fileData) throws Exception {
			
			// 파일명이 중복됐을 때 덮어써지는 것을 방지하기 위해 UUID를 통해 랜덤 문자를 생성해서 파일명에 붙여준다.
			UUID uid = UUID.randomUUID();
			
			String newFileName = uid + "_" + fileName;
			
			// 해당 이미지를 복사해서 지정된 경로에 저장한다.
			File img = new File(uploadPath, newFileName);
			FileCopyUtils.copy(fileData, img);
			
			return newFileName;
		}

}
