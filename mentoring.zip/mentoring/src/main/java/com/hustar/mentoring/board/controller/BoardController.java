package com.hustar.mentoring.board.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.logging.Log;
import org.apache.ibatis.logging.LogFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.hustar.mentoring.board.config.UploadFileUtils;
import com.hustar.mentoring.board.domain.BoardDomain;
import com.hustar.mentoring.board.service.BoardService;
import com.hustar.mentoring.login.domain.MemberDomain;
import com.hustar.mentoring.login.service.MemberDetailService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/menti")
@RequiredArgsConstructor
public class BoardController {

	protected Log log = LogFactory.getLog(this.getClass());
	
	private final BoardService boardService;
	private final MemberDetailService memberDetailService;
	
	// 게시글 List
	@GetMapping(value="/BoardList.do")
	public String BoardList(@ModelAttribute("boardDomain") BoardDomain boardDomain,
			ModelMap model) throws Exception {
		
		// 첫번째 나올 게시글 설정
		boardDomain.setFirstpage((boardDomain.getPageIndex()-1)*boardDomain.getPageUnit());
		
		List<BoardDomain> boardList = (List<BoardDomain>) boardService.selectBoardList(boardDomain);
		
		model.addAttribute("pageing",boardDomain);
		model.addAttribute("boardList", boardList);
		
		return "board";
	}
	
	
	// 게시글 조회
	@GetMapping(value="/BoardView.do")
	public String BoardView(@ModelAttribute BoardDomain boardDomain,
			HttpServletRequest req,
			HttpServletResponse res,
			ModelMap model) throws Exception {
			
			BoardDomain BoardView = (BoardDomain) boardService.selectBoardView(boardDomain);
			
			model.addAttribute("BoardView", BoardView);
		
		
		return "view";
	}
	
	
	// 게시글 등록
	@GetMapping(value="/insertBoard.do")
	public String insertBoard(ModelMap model) throws Exception {
		
		model.addAttribute("actionUrl", "/menti/insertBoardForm.do");
		
		return "insertForm";
	}
	
	
	
	// 게시글 등록 처리
	@PostMapping(value="/insertBoardForm.do")
	public String insertBoardForm(@ModelAttribute BoardDomain boardDomain,
			Authentication auth,
			@RequestParam(value="boardFile1", required = false) MultipartFile file,
			HttpServletRequest req,
			ModelMap model) throws Exception {
		
			int LoginSeq = memberDetailService.findBySeq(auth.getName());
		
			/*// 저장 경로 설정
			String UploadPath = req.getSession().getServletContext().getRealPath("/");				
			String ImgUploadPath = UploadPath.substring(0,UploadPath.length()-7).concat("resources" + File.separator + "static" + File.separator + "Board" + File.separator + "ProfileImg");
			
			
			String fileName = null;
			
			
			if (file != null && !(file.getOriginalFilename().equals(""))) {
				// 파일이 있으면 이름을 가져와서 파일 업로드
				fileName = UploadFileUtils.fileUpload(ImgUploadPath, file.getOriginalFilename(), file.getBytes());
			} else {
				// 파일이 없을때 기본화면을 제공해야함
				fileName = "images" + File.separator + "user.png";
			}
			// 파일 경로를 Domain에 set
			boardDomain.setBoardFilePath1(File.separator + "Board" + File.separator + "ProfileImg" + File.separator +  fileName);*/
			
			// DB 저장
			boardService.insertBoard(boardDomain);
				
			return "redirect:BoardList.do";
	}
	
	// 게시글 수정
	@GetMapping(value="/updateBoard.do")
	public String updateBoard(@ModelAttribute BoardDomain boardDomain,
			HttpServletRequest req,
			HttpServletResponse res,
			ModelMap model) throws Exception {
		
			BoardDomain beforeView = (BoardDomain) boardService.selectBoardView(boardDomain);
			model.addAttribute("beforeView", beforeView);
		
			model.addAttribute("actionUrl", "/menti/updateBoardForm.do");
			
		return "insertForm";
	}
	
	
	// 게시글 수정 처리
	@PostMapping(value="/updateBoardForm.do")
	public String updateBoardForm(@ModelAttribute BoardDomain boardDomain,
			@RequestParam(value="hu_img", required = false) MultipartFile file,
			HttpServletRequest req,
			HttpServletResponse res,
			ModelMap model) throws Exception {
		
			String UploadPath = req.getSession().getServletContext().getRealPath("/");				
			String ImgUploadPath = UploadPath.substring(0,UploadPath.length()-7).concat("resources" + File.separator + "static" + File.separator + "Board" + File.separator + "ProfileImg");
			
			
			String fileName = null;
			
			
			if (file != null && !(file.getOriginalFilename().equals(""))) {
				// 파일이 있으면 이름을 가져와서 파일 업로드
				fileName = UploadFileUtils.fileUpload(ImgUploadPath, file.getOriginalFilename(), file.getBytes());
			} else {
				// 파일이 없을때 기본화면을 제공해야함
				fileName = "images" + File.separator + "user.png";
			}
			// 파일 경로를 Domain에 set
			boardDomain.setBoardFilePath1(File.separator + "Board" + File.separator + "ProfileImg" + File.separator +  fileName);
			
		
			boardService.updateBoard(boardDomain);
		
		return "redirect:BoardList.do";
	}
	
	/*
	@PostMapping(value= "/insertBoardForm.do")
	@ResponseBody
	public ResponseEntity<?> insertBoardForm(@ModelAttribute LoginDomain lgDomain,
			@RequestParam(value = "hu_img", required = false) MultipartFile imgField,
			HttpServletRequest req,
			HttpServletResponse res) throws Exception {
		
			
			
			// 저장 경로 설정
			String UploadPath = req.getSession().getServletContext().getRealPath("/");			
			String ImgUploadPath = UploadPath.substring(0,UploadPath.length()-7).concat("resources" + File.separator + "static" + File.separator +"ProfileImg");
			
			
			String fileName = null;
			
			//System.out.println("")
			
			if (imgField != null && !(imgField.getOriginalFilename().equals(""))) {
				// 파일이 있으면 이름을 가져와서 파일 업로드
				fileName = UploadFileUtils.fileUpload(ImgUploadPath, imgField.getOriginalFilename(), imgField.getBytes());
			} else {
				// 파일이 없을때 기본화면을 제공해야함
				fileName = "images" + File.separator + "user.png";
			}
			// 파일 경로를 Domain에 set
			lgDomain.setHu_img_path(File.separator + "ProfileImg" + File.separator +  fileName);
			
			// DB 저장
			loginService.insertBoard(lgDomain);
			
			URI urilocation = new URI ("/BoardList.do");
			
		return ResponseEntity.created(urilocation).body("{}");
	}*/
	
	// 게시글 삭제
	@PostMapping(value= {"/deleteBoard.do"})
	public String deleteBoard(@ModelAttribute BoardDomain boardDomain,
			HttpServletRequest req,
			HttpServletResponse res,
			ModelMap model) throws Exception{
		
			try {
				
				boardService.deleteBoard(boardDomain);
				
			} catch(Exception e) {
				e.printStackTrace();
				
			}
		
		return "redirect:BoardList.do";
	}
}
