package com.hustar.mentoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
